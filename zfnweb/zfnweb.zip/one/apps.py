from django.apps import AppConfig


class OneConfig(AppConfig):
    name = 'one'
