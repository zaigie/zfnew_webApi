from django.apps import AppConfig


class ChooseConfig(AppConfig):
    name = 'choose'
